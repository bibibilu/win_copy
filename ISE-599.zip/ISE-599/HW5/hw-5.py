import networkx as nx
import matplotlib.pyplot as plt
import random
import numpy as np
import os
import seaborn
from sklearn import linear_model

"""
For  this homework, you will need to have the networkx package installed. If you are using pycharm, you can install
this package just like you installed numpy etc. earlier. If not using pycharm, use pip to install the package in  your
interpreter. For more details, see  networkx's documentation on  installation. It is usually straightforward.
You will know you have succeeded when you do not see an error in  the first line. 

NetworkX webpage: https://networkx.github.io/

As its name suggests, networkx is a 'graph theory' package that you can use to read, write and manipulate
networks of all kinds, including directed, undirected, weighted and attributed networks. It also gives you
many of the tools you'll ever need for getting diagnostic info on a network, including degree distribution,
connected components, and even community detection. I suggest looking at the resources in the tutorial section
to familiarize yourself with the basics: https://networkx.github.io/documentation/latest/tutorial.html
"""

"""
The network that we will be dealing with in this assignment is openly available in Stanford's SNAP ecosystem 
and involves Facebook data: http://snap.stanford.edu/data/ego-Facebook.html

"""

"""
As always, the first step is to download and familiarize yourself with the data. There should be three files at the
bottom of the html page I gave  you the link above for. The network we will be dealing with is facebook_combined.txt.gz,
which you should decompress to get the txt file. Note that sometimes
you have to refresh the page or try a different browser if you don't see the links to the files at the bottom. If none
of those work and you still don't see the files, write to me. 
"""

"""
The dataset that you see is what's called an edge-list. Each line is an edge e.g., 0 10 means that node 0 is linked to
node 10. Numerical IDs have been assigned to nodes for anonymization purposes. In this case, we will treat the network as undirected.
(WCC and SCC on the webpage stand for weakly connected components and strongly connected components. The metrics
are identical for them, as they always are if the network is undirected, since there is no distinction between
weakly connected/strongly connected components, which is why we only use the term 'connected components' in
undirected networks).  
"""

def read_in_network(input_path):
    """
    [5  points] In this function, which could be very short, you should read in  the facebook text file as a
    networkX graph object. See what I said above about the graph being undirected. Hint: there is a very nice
    and elegant way in networkX to read edge lists directly from file into a graph object.
    :param input_path: the path to the decompressed facebook_combined txt file.
    :return: a networkX graph object G
    """
    G = nx.read_edgelist(input_path)
    return G

# print(read_in_network('C:/Users/Claire/PycharmProjects/ISE-599/HW5/facebook_combined.txt'))

def verify_webpage_numbers(G):
    """
    [25 points] In this function, write code (you can use networkX functionality to any extent that you wish) to verify
    the numbers on the SNAP webpage describing this dataset regarding the average clustering coefficient, the number of
    triangles, the diameter, and the nodes and edges in the largest connected component. Is there any discrepancy?
    Please report if so.
    [Output]
    the average clustering coefficient: 0.6055
    the diameter: 8
    the number of triangles:  4836030
    the nodes in the largest connected component:  4039
    the edges in the largest connected component:  88234
    ***the number of triangles is different from that on the SNAP webpage '1612010'

    :param G: the networkX graph object
    :return: None
    """
    ave_clustering_coef = nx.average_clustering(G)
    num_of_triangles = sum(nx.triangles(G).values())
    diameter = nx.diameter(G)
    lcc = max(nx.connected_components(G), key=len)
    nodesNum_in_lcc = len(lcc)
    edgesNum_in_lcc = len(G.subgraph(lcc).edges())
    print('the average clustering coefficient:', round(ave_clustering_coef, 4))
    print('the number of triangles:', num_of_triangles)
    print('the diameter:', diameter)
    print('the nodes in the largest connected component:', nodesNum_in_lcc)
    print('the edges in the largest connected component:', edgesNum_in_lcc)


# G = read_in_network('C:/Users/Claire/PycharmProjects/ISE-599/HW5/facebook_combined.txt')
# verify_webpage_numbers(G)


def degree_distribution(G, subtitle, out_folder):
    """
    [15 points] Plot the  degree distribution on a log-log plot. You can use python (e.g., matplotlib and pyplot if you
    wish for the plot, or collect data  and plot it somewhere else, like excel).
    Does the degree distribution obey the power
    law well? If  so, what is the power-law coefficient? (Recall that a power law says that the prob(k) of degree
    k is proportional to k^{-gamma}. Gamma is known as  the power-law coefficient (it also has other names).

    The plot should be separately included with  your homework submission (a short PDF report, containing answers/figures,
    with captions to any questions that cannot be directly answered in file here)
    :param G: the networkX graph object
    :return: None
    """

    #[5 points] How many friends does the node with the highest degree have? What is the clustering coefficient
    # of that node? Interpret the result: do you believe this individual is a member of a cohesive and tightly knit
    # group  or more like a central figure that people are connecting to for some reason (e.g., celebrity status
    # or because the person is popular, or just adding lots of friends on facebook for no reason, as some people do)
    # [Answer]:
    # Node with highest degree is '107', which has 1045 friends. The clustering coefficient of '107' is 0.049. It seems
    # more likely that this individual just adding lots of friends for no reason since its clustering coefficient is extremely low.

    #[10 points extra credit]. Separately report the degree distributions of the ten individual networks on the dataset
    #webpage under file facebook.tar.gz. The folder (obtained upon decompressing) contains many files; edge lists are contained in [num].edges files.
    degree_dist = {}
    # degrees = [G.degree(n) for n in G.nodes()]
    # plt.hist(degrees)
    # plt.xscale('log')
    # plt.yscale('log')
    # plt.show()
    for n in G.nodes():
        degree = G.degree(n)
        if degree not in degree_dist:
            degree_dist[degree] = 0
        else:
            degree_dist[degree] += 1
    deg = sorted(degree_dist.items())
    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.plot([k for (k,v) in deg], [v for (k,v) in deg])
    ax.set_xscale('log')
    ax.set_yscale('log')
    plt.title(subtitle + ' Degree Distribution')
    plt.savefig(out_folder + subtitle + '.png')
    plt.show()

# degree_distribution(G)

def main_report(input_path, out_folder):
    G = read_in_network(input_path)
    node_degree = {}
    for n in G.nodes():
        degree = G.degree(n)
        node_degree[n] = degree
    print(sorted(node_degree.items(), key=lambda x: x[1], reverse=True))
    for k, v in node_degree.items():
        if v == max(node_degree.values()):
            print(k, v, nx.clustering(G, nodes=k))
    degree_distribution(G, 'Facebook_combined', out_folder)

# main_report('C:/Users/Claire/PycharmProjects/ISE-599/HW5/facebook_combined.txt', 'C:/Users/Claire/PycharmProjects/ISE-599/HW5/')


def getFilelist(in_folder):
    filelist = []
    files = os.listdir(in_folder)
    for fname in files:
        if 'edges' in fname:
            filelist.append(fname)
    return filelist

def extra_individual_networks(in_folder, out_folder):
    file_list = getFilelist(in_folder)
    for fname in file_list:
        G = nx.read_edgelist(in_folder + fname)
        degree_distribution(G, fname[:-6]+' Individual', out_folder)

# extra_individual_networks(in_folder='C:/Users/Claire/PycharmProjects/ISE-599/HW5/facebook/', out_folder='C:/Users/Claire/PycharmProjects/ISE-599/HW5/')

"""
Now, we will analyze what happens to the metrics if you only get to observe a 'fraction' of the network, as most of us do when
we are working  with these kinds of networks at very large-scale. 
"""

def sample_edges(G, num_edges):
    """
    [10 points] Complete the code. Make sure to use numpy or scipy for your sampling needs, as always. Note that because
    we are sampling edges, rather than nodes, nothing can be said about the number of nodes in the output graph. In theory,
    because there are roughly 4000+ nodes, you may end up getting all nodes even if you sample only 5000 edges!
    :param G: the original graph
    :param num_edges: number of edges to sample. If -1 or greater than the total number of edges in G, just
    return the full graph G.
    :return: another graph H that contains num_edges randomly sampled edges from G
    """
    if num_edges == -1 | num_edges > len(G.edges):
        return G
    else:
        edges_sample = random.sample(G.edges, num_edges)
        H = nx.Graph()
        H.add_edges_from(edges_sample)
        return H

"""
[40 points]
Use  the function above  (including any others you need) to randomly sample edges from G to produce four graphs with 15000, 30000, 45000 and 60000 edges respectively.
Now re-compute the  average clustering coefficient, fraction of closed triangles and diameter (note that
if the graph is disconnected, the diameter is infinite. Please note if this happens) on these graphs. For
best results, you should sample (for each size) ten times and then compute averages and standard deviations of the network metrics noted above. Ignore infinite diameters
for the purpose of averaging, unless  the majority of diameters in  your 10-sample are infinite. 

In the report, tabulate these results and provide a succinct conclusion. Is there a sample size at which the
network starts looking like the original network? Which (if any) of the quantities you have computed above
are reliable and at what sampling  threshold? For example, you may conclude, 'fraction of closed triangles starts
approaching the level in  the original network even in the 15000 edge sample, but the diameter continues to be
untrustworthy till we see at least 45000 edges...'. 

I am looking for short, insightful reports. Statistical significance testing, if applied will boost your score. 
In particular, look to such testing for writing a decisive conclusion. 
[Output]
{15000: {'clusterCoef_ave': 0.08853710482862921, 'triangle_ave': 23526.0, 'diam_ave': nan, 'clusterCoef_std': 0.0, 'triangle_std': 0.0, 'diam_std': nan, 'disconnect_count': 10}, 30000: {'clusterCoef_ave': 0.18864824484395165, 'triangle_ave': 187350.0, 'diam_ave': nan, 'clusterCoef_std': 0.0, 'triangle_std': 0.0, 'diam_std': nan, 'disconnect_count': 10}, 45000: {'clusterCoef_ave': 0.2988137262264815, 'triangle_ave': 643509.0, 'diam_ave': nan, 'clusterCoef_std': 0.0, 'triangle_std': 0.0, 'diam_std': nan, 'disconnect_count': 10}, 60000: {'clusterCoef_ave': 0.4038559470014612, 'triangle_ave': 1512114.0, 'diam_ave': nan, 'clusterCoef_std': 0.0, 'triangle_std': 0.0, 'diam_std': nan, 'disconnect_count': 10}}  
"""
def calculate_metrics(G):
    ave_clustering_coef = nx.average_clustering(G)
    num_of_triangles = sum(nx.triangles(G).values())
    order = G.order()
    for n in G.nbunch_iter():
        length = len(nx.single_source_shortest_path_length(G, n))
        if length != order:
            diameter = np.inf
        else:
            diameter = nx.diameter(G)
    return ave_clustering_coef, num_of_triangles, diameter


def calculate_sample_metrics(G):
    sample_metrics ={}
    clusterCoef_list = []
    triangle_list = []
    diam_list = []
    # clusterCoef_total = 0
    # triangle_total = 0
    # diam_total = 0
    disconnect_count = 0
    for trial_num in range(0,10):
        ave_clustering_coef, num_of_triangles, diameter = calculate_metrics(G)
        clusterCoef_list.append(ave_clustering_coef)
        triangle_list.append(num_of_triangles)
        if diameter == np.inf:
            disconnect_count += 1
        else:
            diam_list.append(diameter)
        # clusterCoef_total += ave_clustering_coef
        # triangle_total += num_of_triangles
        # diam_total += diameter
        # if diameter == -1:
        #     disconnect_count += 1
            # diam_total -= -1
    clusterCoef_ave = np.mean(clusterCoef_list)
    triangle_ave = np.mean(triangle_list)
    diam_ave = np.mean(diam_list)
    clusterCoef_std = np.std(clusterCoef_list, ddof=1)
    triangle_std = np.std(triangle_list, ddof=1)
    diam_std = np.std(diam_list, ddof=1)
    sample_metrics_dict ={}
    sample_metrics_dict['clusterCoef_ave'] = clusterCoef_ave
    sample_metrics_dict['triangle_ave'] = triangle_ave
    sample_metrics_dict['diam_ave'] = diam_ave
    sample_metrics_dict['clusterCoef_std'] = clusterCoef_std
    sample_metrics_dict['triangle_std'] = triangle_std
    sample_metrics_dict['diam_std'] = diam_std
    sample_metrics_dict['disconnect_count'] = disconnect_count
    return sample_metrics_dict
    # return [clusterCoef_ave, triangle_ave, diam_ave, disconnect_count]


def master(G):
    metrics_dict = {}
    for num_edges in [15000, 30000, 45000, 60000]:
        H = sample_edges(G, num_edges)
        metrics_list = calculate_sample_metrics(H)
        metrics_dict[num_edges] = metrics_list
    return  metrics_dict.items()

# print(master(G))

"""
[10 points extra credit]. You are trying to sample x edges, and the metric of success is the degree distribution
(both in shape and if the power-law applies, the power-law coefficient) and its similarity for your sampled network
to the original network. Rounded to the nearest 5000, at what point does your sample bring you 'close enough' to the original (i.e. what is the value of x we should use)?
We are qualitatively unwilling to accept an 'error' of more than 10% e.g., the true coefficient must be within  10% of
the coefficient you get from your sampled network's degree distribution. 
"""

def master_extra(input_path):
    G = read_in_network(input_path)
    degree_dict = {}
    degrees = G.degree()
    for pair in degrees:
        degree_dict[pair[0]] = pair[1]
    degree_values = sorted(set(degree_dict.values()))
    histogram = [list(degree_dict.values()).count(i) / float(nx.number_of_nodes(G)) for i in degree_values]
    plt.plot(degree_values, histogram, 'o')
    plt.xlabel('Degree')
    plt.ylabel('Fraction of Nodes')
    plt.xscale('log')
    plt.yscale('log')
    plt.show()
    X = np.log10(degree_values)  # 对X，Y取双对数
    Y = np.log10(histogram)
    return X, Y

# master_extra('C:/Users/Claire/PycharmProjects/ISE-599/HW5/facebook_combined.txt')

def power_law():
    X_parameter=[]
    Y_parameter=[]
    for  deg, freq in zip(X,Y):
       X_parameter.append([deg])
       Y_parameter.append(freq)



# good luck!