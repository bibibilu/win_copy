# import codecs
# import re
from numpy import *
import numpy as np
from fractions import Fraction

# data = mat([[34, -7, -12, 4],
#             [-7, 2, 17, -12],
#             [-12, 17, 2, 12],
#             [4, -12, 12, -4]])
data = mat([[1, 0],
            [-1, 1]])
data_4 = data.I

# for i in range(3):
#     for j in range(3):
#         print(Fraction(data_4[i, j]))
        # print(data_4[i,j])

data_5 = mat([[11], [22], [21], [8]])
# CBI = data_5 * data
# z_c = CBI * mat([[-1], [-2], [5]])
# print(z_c)
print(data_4)
# print(data * data_5)
#
# root path = ""
#
# with codecs.open(root path: "wine.data", "r", "utf-8") as f:
#     for line in f:
#          l = line[0:-1]
#          fields = re.split(",", l)
#          fields_num = [float(i) for i in fields]
#          print fields_num
#          break
