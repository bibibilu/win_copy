import os
import re
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import BernoulliNB
from sklearn.linear_model import SGDClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import LeaveOneOut, cross_val_score
from sklearn.metrics import accuracy_score


"""
At this point I am assuming that:

--you are comfortable writing and testing python code for the purposes of these homeworks.

--you are comfortable with statistical/ML tools like sklearn and numpy.

--if given reasonable problems involving featurization of raw data, training, testing, sampling etc., you
 can figure out reasonable solutions to these problems.r

Good luck!
"""


"""     
[30 points] Replace 'pass' below as appropriate. Make sure to read the notes in the function header.
<The main goal of this function is to ensure you can use the 'tfidf' function offered in the sklearn
lib: https://scikit-learn.org/stable/modules/generated/sklearn.feature_extraction.text.TfidfVectorizer.html>

"""

def getFilelist(in_folder):
    filelist = []
    files = os.listdir(in_folder)
    for f in files:
        filelist.append(f)
    return filelist


def readFile(in_folder, filename, subject):
    f = open(in_folder + filename, 'r')
    if subject:
        text = re.sub(r'[Subject:\n]', '', f.readline())
    else:
        f.readline()
        f.readline()
        text = re.sub(r'[\n]', '', f.readline())
    return text


def generateCorpusLabels(in_folder, subject):
    file_list = getFilelist(in_folder)
    corpus = []
    label_list = []
    for fname in file_list:
        content = readFile(in_folder, fname, subject)
        corpus.append(content)
        if 'legit' in fname:
            label_list.append(0)
        else:
            label_list.append(1)
    return corpus, label_list


def encode_text_tfidf_vectors(in_folder, subject, case): # replace this path with your own after you've unzipped the input file.
    """
    1. The goal of this function is to take the path to your text file, open the file, read in/encode the text files as tf-idf vectors
    and labels and output the tf-idf matrix X and the labels-vector y. You may use the sk-learn tf-idf vectorizer
    with default parameters. Initially, the goal should be to get the full system working rather than 'optimize'
    the tf-idf and its parameters for best performance.

    2. Note that the text in the input files has been 'encoded' (in this case, each word has been assigned to a number.
    This makes your job easier, not harder, since it means we won't have to process the 'raw' text and perform NLP-based preprocessing
    like tokenization/word segmentation etc.). Make sure to read the readme file to understand what's going on here, including
     on how the name of the file tells you whether a file is 'legit' or 'spam'

     Hint: A useful package here is https://docs.python.org/2/library/os.html#os.listdir, which comes with python
     and allows you to directly list/manipulate files in folders etc. Other ways are fine too, as long as your
     approach is programmatic (i.e. you are not allowed to manually input the names of files in this

     3. If subject is false, then that means you should only produce the tf-idf of the 'main body'. If subject is true,
     then you should produce the tf-idf of only the subject (see extra credit question at the end of this program).
     In no time during this homework will we be producing the
     tf-idf of the subject+main body combined.

     Hint: You will need to parse the contents of the file accordingly. The package 're' (also included in the python
     system lib) is your friend.
    """
    corpus, labels = generateCorpusLabels(in_folder, subject)
    y = np.array(labels)
    if case == 0:
        vec = TfidfVectorizer()
    if case == 1:
        vec = TfidfVectorizer(max_df=0.70, min_df=0.1)
    if case == 2:
        vec = TfidfVectorizer(max_df=0.80, min_df=5)
    if case == 3:
        vec = TfidfVectorizer(max_df=0.90, min_df=0.2)
    tf_idf = vec.fit_transform(corpus)
    vocabulary = vec.get_feature_names()
    X = tf_idf.toarray()
    return vec, vocabulary, X, y

# print(encode_text_tfidf_vectors(in_folder='C:/Users/Claire/PycharmProjects/ISE-599/HW4/train/', subject=False, case=0))

"""
[30 points] Train a classifier on the train dataset that is able to predict spam. You must:
--Try at least five different classifiers
--Try at least three different tf-idf 'settings' i.e. try to play with the parameters in the sklearn tf-idf vectorizer to achieve
optimal performance (measured using 'accuracy' i.e. the percentage of correct classifications).
--Use some kind of 'validation' mechanism to ensure that you truly select the best classifier and don't overfit. There
are several ways of achieving this including (i) cross validation (if you are able to do it), or (ii) split your 'original' training
data into a 'training' and 'validation' set (e.g., maybe using an 80/20 or 90/10 split). Use the 'training' portion
for training your classifier, and your 'validation' portion for getting an unbiased estimate of classifier performance.
Make sure to use stratified sampling (the code from the previous HW is your friend here).

You MUST NOT use the test dataset at all for this part of the experiment. The deliverable for this exercise should
be both the code that you write below as well as a short report showing results for the different things you tried.
 The report can be a spreadsheet, text, word etc. but we must be able to read and understand it. Shorter is better,
 but not at the cost of readability/clarity. Be liberal in your use of tables/diagrams. For example, you could produce
 a table with 5 X 3 rows, showing performance on the validation set for each of the fifteen things you tried.
 ANSWER:
 [Output]
 case = 1 : max_df=0.70, min_df=0.1
 case = 2 : max_df=0.80, min_df=5   
 case = 3 : max_df=0.90, min_df=0.2 
 
accuracy_rate
 case  decision_tree  naive_bayes  support_vector_machine  k_neighbours	  logistic_regression	linear_SGD_classifier	
 1	   1              0.929577465  0.971830986             0.887323944   0.816901408           0.985915493	
 2	   1              0.915492958  1                       0.915492958   0.830985915           0.985915493	
 3	   1              0.929577465  0.971830986             0.915492958   0.816901408           1
*From the accuracy_rate table, we can say that the performance is relatively the best in case 2 in general and it is
 apparent that decision_tree, support_vector_machine and linear_SGD_classifier predict with better accuracy.
 Then, the cross validation is applied on these classifiers in case 2 to see which are better classifiers for real.
 
Cross_validation_score in case 2:
 case  decision_tree  naive_bayes  support_vector_machine  k_neighbours  logistic_regression  linear_SGD_classifier
 2     0.816901408    0.873239437  0.929577465             0.873239437   0.802816901          0.915492958
*According to the cross_validation_score, we can see even though the prediction of decision_tree is 100% accurate, its 
 cross_validation score for is relatively low, which means decision_tree model is over-fitted. Thus the real better two
 classifiers are support_vector_machine and linear_SGD_classifier.

 [10 points] Using the best and second-best classifiers you got from above, apply them once each on the entire test dataset.
 If you run into the out-of-vocabulary problem i.e. there are words in your test data that are not in your training data,
 you can delete the word, although in practice we would be taking a more sophisticated approach, as I highlighted in class.
 What are the accuracy measures you are getting for both? Is the difference greater, smaller or equal compared to performance
 difference on validation set/cross-validation? What would be the accuracy for a classifier that labeled the data 'randomly'?
 (Hint: for the last question, use a bernoulli distribution i.e. toss a coin, with spam coming up with probability p and non-spam
 with probability 1-p. Use the number of spam/legit samples in the training data to estimate the ideal value for p.)
 ANSWER:
 [Output]
                         support_vector_machine  linear_SGD_classifier  difference
  testDataset_accuracy   0.971831                0.957746               0.014085
  crossValidation_score  0.929577                0.915493               0.014085
 *From the difference table, we can see that the difference does not change.
 
 *P = 0.19718309859154928
  The accuracy for a classifier that labeled the data 'randomly' is 0.6833961515572308.
"""

def train_models(X_train, y_train, model):
    if model == 'decision_tree':
        m = DecisionTreeClassifier(presort=True, random_state=0)
    if model == 'naive_bayes':
        m = BernoulliNB(fit_prior=True)
    if model == 'support_vector_machine':
        m = SVC(C=2, kernel='linear', random_state=0)
    if model == 'k_neighbours':
        m = KNeighborsClassifier()
    if model == 'logistic_regression':
        m = LogisticRegression(solver='lbfgs', max_iter=3000, random_state=0)
    if model == 'linear_SGD_classifier':
        m = SGDClassifier(penalty='l2', alpha=0.01, max_iter=10000, tol=1e-3, random_state=0)
    clf = m.fit(X_train, y_train)
    return clf


def evaluateModel(X, y, model):
    y_predict = model.predict(X)
    return accuracy_score(y, y_predict)


def cross_Validation(model, X, y):
    loo = LeaveOneOut()
    results = cross_val_score(model, X, y, cv=loo, scoring='accuracy')
    accuracy_rate = results.mean()
    return accuracy_rate


def compareModel(X, y):
    model_list = ['decision_tree', 'naive_bayes', 'support_vector_machine', 'k_neighbours', 'logistic_regression', 'linear_SGD_classifier']
    accuracy_rate = {}
    CV_score = {}
    for model in model_list:
        clf = train_models(X, y, model)
        accuracy = evaluateModel(X, y, clf)
        accuracy_rate[model] = accuracy
        score = cross_Validation(clf, X, y)
        CV_score[model] = score
    return accuracy_rate, CV_score


def generate_compare_df(in_folder, subject, out_folder):
    case_list = [1, 2, 3]
    accuracy_df = pd.DataFrame()
    CV_score_df = pd.DataFrame()
    # corpus, labels = generateCorpusLabels(in_folder, subject)
    for caseNo in case_list:
        vec, vocab, X, y = encode_text_tfidf_vectors(in_folder, subject, caseNo)
        accuracy_dict, CV_score_dict = compareModel(X, y)
        accuracy_dict['Case'] = caseNo
        temp_df1 = pd.DataFrame([accuracy_dict])
        accuracy_df = pd.concat([accuracy_df, temp_df1])
        if caseNo == 2:
            CV_score_dict['Case'] = caseNo
            temp_df2 = pd.DataFrame([CV_score_dict])
            CV_score_df = pd.concat([CV_score_df, temp_df2])
    df_set = accuracy_df, CV_score_df
    writer = pd.ExcelWriter(out_folder)
    for i in range(len(df_set)):
        df_set[i].to_excel(out_folder, index=False)
        df_set[i].to_excel(excel_writer=writer, sheet_name=str(i))
    writer.save()
    writer.close()
    return accuracy_df, CV_score_df

# print(generate_compare_df('C:/Users/Claire/PycharmProjects/ISE-599/HW4/train/', False, 'C:/Users/Claire/PycharmProjects/ISE-599/HW4/model_comparison.xls'))


def delete_outof_Vocabulary(corpus_1, corpus_2):
    wordset_1 = set([word_1 for content_1 in corpus_1 for word_1 in content_1])
    for content_2 in corpus_2:
        for word_2 in content_2:
            if word_2 not in  wordset_1:
                content_2.remove(word_2)
    return corpus_2


def test_data_prediction(in_folder_train, in_folder_test, subject, case):
    corpus_train, label_train = generateCorpusLabels(in_folder_train, subject)
    corpus_test, label_test = generateCorpusLabels(in_folder_test, subject)
    corpus_test_update = delete_outof_Vocabulary(corpus_train, corpus_test)
    vector, vocab, X_train, y_train = encode_text_tfidf_vectors(in_folder_train, subject, case)
    X_test = vector.transform(corpus_test_update).todense()
    y_test = np.array(label_test)
    acc_dict = {}
    CV_score_dict = {}
    for model in ['support_vector_machine', 'linear_SGD_classifier']:
        clf = train_models(X_train, y_train, model)
        accuracy = evaluateModel(X_test, y_test, clf)
        score = cross_Validation(clf, X_train, y_train)
        acc_dict[model] = accuracy
        CV_score_dict[model] = score
    acc_df = pd.DataFrame([acc_dict])
    CV_score_df = pd.DataFrame([CV_score_dict])
    difference_df = pd.concat([acc_df, CV_score_df], axis=0)
    difference_df['difference'] = difference_df['support_vector_machine'] - difference_df['linear_SGD_classifier']
    return acc_dict, difference_df

# print(test_data_prediction(in_folder_train='C:/Users/Claire/PycharmProjects/ISE-599/HW4/train/', in_folder_test='C:/Users/Claire/PycharmProjects/ISE-599/HW4/test/', subject=False, case=2))


def estimate_bernoulli_p(in_folder):
    filelist = getFilelist(in_folder)
    count_spam = 0
    for fname in filelist:
        if 'legit' not in fname:
            count_spam += 1
    p = count_spam/len(filelist)
    accuracy = p**2 + (1-p)**2
    return p, accuracy

# print(estimate_bernoulli_p('C:/Users/Claire/PycharmProjects/ISE-599/HW4/train/'))


"""
[20 points Extra Credit] Using the subject tf-idf rather than main-body, re-train your classifier/model of choice above (you
 do not have to try out fifteen different things for this exercise), and apply it to the test set (again, using subject tf-idf
 as features). Does the performance improve? 
 ANSWER:
 [Output]
 case = 1 : max_df=0.70, min_df=0.1
 case = 2 : max_df=0.80, min_df=5   
 case = 3 : max_df=0.90, min_df=0.2 
 
    accuracy_of_the_mainbody
    case  support_vector_machine  linear_SGD_classifier
    1     0.929577465	          0.929577465
    2     0.971830986	          0.957746479
    3     0.901408451	          0.929577465
     
    accuracy_of_the_subject
    case  support_vector_machine  linear_SGD_classifier
    1     0.802816901	          0.802816901
    2     0.788732394	          0.802816901
    3     0.915492958	          0.915492958
 
 *As we can see, except that the accuracy performance does not change much in case 3, the performance decreases a lot in 
  case 1 and 2 for both chosen classifiers when using the subject tf-idf rather than main-body.

"""
def master_extra(in_folder_train, in_folder_test, out_folder):
    df_mainbody = pd.DataFrame()
    df_subject = pd.DataFrame()
    for caseNo in [1, 2, 3]:
        accu_rate_mainbody = test_data_prediction(in_folder_train, in_folder_test, False, caseNo)[0]
        accu_rate_subject = test_data_prediction(in_folder_train, in_folder_test, True, caseNo)[0]
        temp_1 = pd.DataFrame([accu_rate_mainbody])
        temp_2 = pd.DataFrame([accu_rate_subject])
        df_mainbody = pd.concat([df_mainbody, temp_1], axis=0)
        df_subject = pd.concat([df_subject, temp_2], axis=0)
    df_set = df_mainbody, df_subject
    writer = pd.ExcelWriter(out_folder)
    for i in range(len(df_set)):
        df_set[i].to_excel(out_folder, index=False)
        df_set[i].to_excel(excel_writer=writer, sheet_name=str(i))
    writer.save()
    writer.close()
    return df_mainbody, df_subject

# print(master_extra('C:/Users/Claire/PycharmProjects/ISE-599/HW4/train/', 'C:/Users/Claire/PycharmProjects/ISE-599/HW4/test/', 'C:/Users/Claire/PycharmProjects/ISE-599/HW4/mainbody_subject__comparison.xls'))




