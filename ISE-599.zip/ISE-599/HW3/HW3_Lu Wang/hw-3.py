import sklearn  # make sure this is installed in your environment.
from sklearn.datasets import *
from sklearn import tree
import pandas as pd
import numpy as np
from collections import Counter
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import BernoulliNB
from sklearn.linear_model import SGDClassifier
from sklearn.ensemble import RandomForestClassifier
from scipy import stats
from statsmodels.sandbox.stats.multicomp import multipletests

"""
This homework assumes that you have completed hw-2 and are familiar 'enough' with Python by now. Our main goal
in this homework is to play with sklearn, which is the primary toolkit in Python that is used for basic machine
learning like the models we studied in class (Naive Bayes, decision trees, linear classifiers and regressors).

For our experiments, we will use a dataset publicly available in the UCI repository, namely the Bank Marketing Data Set.
Go to the website to read more: https://archive.ics.uci.edu/ml/datasets/Bank+Marketing

Note that we will be using the bank-additional-full.csv file for our experiments. This is the most complete
dataset (i.e. has all 41,000+ examples and 20 attributes). It is a binary classification task (the very last column,
which is either a yes or a no). However, as you'll see, even before we can get to all the good model fitting
stuff, there's some data cleaning/processing that we'll need to do first.

In python we often use 'pass' as a placeholder. Wherever you see 'pass', it's a sign that you should replace with
your own code (which could span multiple lines).

If it makes you comfortable to define additional functions or data structures to help you, go for it.

Do not forget to 'call' the functions as necessary, as you proceed with the assignment.

HINT: The first part of this exercise (in my opinion) is the most time-consuming, despite technically being
the easiest, just like in actual analytics projects (remember what I said in one of the classes about 80-90% time
in machine learning/data science projects in the real-world being taken up by 'data cleaning/wrangling'?). I realize
 that you may want to work on some of the other stuff before being able to parse the file into a matrix. One piece of
 advice is that many of the other function rely on generic matrices X and y, which you can get from sklearn's
 sample datasets. I'll provide some guidance below. The important thing to remember is, you can  'test' the functions
 out of order, although to complete the assignment you will need to finish everything I ask you below.

 Perhaps a shorter way to state the hint above is, read the entire assignment before jumping on to it, and be
 strategic about how you allocate time to the various problems. Don't get frustrated!

 (Another) HINT: Make sure you have imported everything you need at the top of this file!

 Total possible points are 100, not including 10 extra credit point opportunities.

Good luck!
"""

"""
[30 points] Complete encode_record_into_vector and parse_file_into_matrix
"""

col_encode = {}
index_encode = {}

def encode_record_into_vector(record):
    """
    the goal of this function is to take a record (informally, a 'row' in your file)
    and 'encode' it numerically so that we can actually do
    machine learning with it. How you do the encoding is up to you, but one recommended way is to:
    --leave the numeric variables (like age) as is
    --assign a numeric value to each possible value of a categorical variable. For example, for the categorical
    variable 'loan', we have three possible values ('no', 'yes', 'unknown'). We may want to assign 'no' to 0,
    'yes' to 1 and 'unknown' to -1. Similarly, for 'month' the encoding is easy (1 for 'jan', 2 for 'feb'...12 for 'dec')
    :param record: I highly recommend that record be a 'dict', but you can use other data structures (like 'list') if
    you want. For example,
    you could even just pass in a string! However, the output MUST be a numeric vector.
    Also, we will not do 'type' checking on this function, so you don't need to waste time checking for exceptions,
    or worrying that we will try to trip you up by running your code using weird inputs.
    The only requirement is that code you write must work for the dataset used in this assignment.
    :return:
    x: the vector representation of the record

    """
    # day_encode = {'mon': 1, 'tue': 2, 'wed': 3, 'thu': 4, 'fri': 5}
    # month_encode = {'jan': 1, 'feb': 2, 'mar': 3, 'apr': 4, 'may': 5, 'jun': 6, 'jul': 7, 'agu': 8, 'sep': 9, 'oct': 10,
    #                 'nov': 11, 'dec': 12}
    # edu_encode = {'unknown': -1, 'illiterate': 0, 'basic.4y': 1, 'basic.6y': 2, 'basic.9y': 3, 'high.school': 4,
    #               'university.degree': 5, 'professional.course': 6}
    # poutcome_encode = {'nonexistent': -1, 'failure': 0, 'success': 1}
    # contact_encode = {'telephone': 1, 'cellular': 2}
    # job_encode = {'unknown': -1, 'unemployed': 0, 'retired': 1, 'self-employed': 2, 'housemaid': 3, 'services': 4,
    #               'blue-collar': 5, 'technician': 6, 'admin.': 7, 'management': 8, 'entrepreneur': 9}
    # marital_encode = {'unknown': -1, 'single': 0, 'married': 1, 'divorced': 2}
    # dhl_encode = {'unknown': -1, 'no': 0, 'yes': 1}
    # y_encode = {'no': 0, 'yes': 1}
    #
    # dic_encode = {}
    # dic_encode['job'] = job_encode
    # dic_encode['marital'] = marital_encode
    # dic_encode['education'] = edu_encode
    # dic_encode['default'] = dhl_encode
    # dic_encode['housing'] = dhl_encode
    # dic_encode['loan'] = dhl_encode
    # dic_encode['contact'] = contact_encode
    # dic_encode['month'] = month_encode
    # dic_encode['day_of_week'] = day_encode
    # dic_encode['poutcome'] = poutcome_encode
    # dic_encode['y'] = y_encode

    # record_df = pd.DataFrame([record])
    # for var, encode in dic_encode.items():
    #     record_df[var] = record_df[var].map(dic_encode[var])
    # x = np.array(record_df.iloc[0])
    x = None
    record_dic = {}
    for i in record:
        if type(record[i]) == str:
            if i not in col_encode:
                col_encode[i] = {}
                index_encode[i] = 0
            if record[i] not in col_encode[i]:
                col_encode[i][record[i]] = index_encode[i]
                index = index_encode[i]
                index += 1
                index_encode[i] = index
            record_dic[i] = col_encode[i][record[i]]
        else:
            record_dic[i] = record[i]
    record_df = pd.DataFrame([record_dic])
    x = np.array(record_df.iloc[0])
    # Hint: use 'encoding' dictionaries to help you and avoid messy if-then code.
    # For example, for 'loan', an encoding dictionary might be loan={'no':0,'yes':1,'unknown':-1}. With some
    # concise coding, you could use this dict to encode categorical values into numbers.

    return x


def parse_file_into_matrix(file_name):
    """
    Hint 1: Even though the file is a .csv, be careful about using Python's csv package for reading in the file.
    The single biggest source of error is not reading in the file correctly. It's good to test that you're
    doing the initial data processing correctly on the first few records.

    Hint 2: This function will make a call to encode_record_ for each record (not including header) in your input file
    :param file_name: The path to the bank-additional-full.csv file
    :return:
    X: A D X 20 matrix, where D is the number of 'instances' or records in the file (the number of columns may be more
    than 20 if you use some alternate coding scheme than the one I recommended in encode_record_ (e.g., one-hot encoding)
    y: A D X 1 matrix containing only 1's (for 'yes' in the output variable) or 0's (for 'no')
    """
    X = None
    y = None
    df = pd.read_csv(file_name, sep=';')
    for rowNo in range(0, len(df)):
        row_series = df.iloc[rowNo]
        row_dict = row_series.to_dict()
        row_mat = encode_record_into_vector(row_dict)
        row_X = np.delete(row_mat, -1)
        row_y = row_mat[-1:]
        if X is None:
            X = row_X
            y = row_y
        else:
            tup1 = (X, row_X)
            tup2 = (y, row_y)
            X = np.vstack(tup1)
            y = np.vstack(tup2)
    X = np.nan_to_num(X)
    y = np.nan_to_num(y).ravel()
    return (X, y)


def generate_encode_file(input_file, output_file):
    file_mat = parse_file_into_matrix(input_file)
    Xy_combine = np.hstack((file_mat[0], file_mat[1]))
    np.savetxt(output_file, Xy_combine, delimiter=',')

# generate_encode_file(input_file='C:/Users/Claire/PycharmProjects/ISE-599/HW3/bank-additional-full.csv', output_file='C:/Users/Claire/PycharmProjects/ISE-599/HW3/Xy_encode_full_update.txt')


"""
We will define 'positive' instances as those with label 1, and negative instances as those with label 0.

Q1 [5 points]. Write some code to count the number of 1s and 0s in y. How many positive and negative instances each
are in your dataset?
ANS: There are 4640 positive and 36548 negative instances each.
Output: Counter({0.0: 36548, 1.0: 4640})
"""

def value_count(file_name):
    file_mat = parse_file_into_matrix(file_name)
    y_mat = file_mat[1]
    count_dic = Counter(y_mat.ravel())
    return count_dic

# print(value_count(file_name='C:/Users/Claire/PycharmProjects/ISE-599/HW3/bank-additional-full.csv'))

"""

If you want to do the next part before the previous part, I recommend calling X_y_for_running_tests below,
which reads in a sample dataset from sklearn. I've included a short snippet of code below for your reference. Remember, however, that
to score points, you must work with the banking dataset in the output you submit.
"""

def X_y_for_running_tests():
    # just call this, and it will return X and y.
    X, y = load_digits(2, True) # return only two classes, although there are ten total
    return X, y

# X, y=X_y_for_running_tests()
# print(X)
# print('now printing y')
# print(y)

def training_testing_split(X, y, training_ratio):
    """
    Here's an opportunity to test your sampling skills  using numpy. We want to do stratified sampling on X, y. Basically,
     this means that we want to 'split' the original X, y (the 'complete' dataset) into a training dataset (X_train, y_train)
     that will be used for training the model, and a testing dataset (X_test, y_test) that will be used for evaluating
     the model. Here are the requirements:
     --Since the sampling is stratified, we want to make sure that the proportion of positive instances (to total instances)
     is equal in both training and testing data. For example:
        Imagine that you had 100 positive instances and 50 negative instances in your full dataset. Suppose the training_Ratio
        is 80%, as specified by default in the signature. Then, we want to randomly sample 0.8*100 positive instances (or 80
        instances) and 0.8*50 negative instances (or 40 instances) and place all 120 instances in X_train (correspondingly, y_train
        is filled with 1s and 0s based on the label). The remaining 30 instances (20 positive and 10 negative) are
        placed in X_test (with y_test populated with 1s and 0s correspondingly). Notice that the ratio of positive
        to positive+negative is equal in both training and testing datasets (compute it for yourself), and by extension,
        so is the ratio of negative to positive+negative. There is a very good reason why this is so important (recall
        the definition of learning in our very first slide! Would the test data still be from the same population as the
        training data if we did not decide to 'stratify' the sample in this way?)
     --Your method should work for any numeric choice of   and training ratio (that is between 0 and 1, including the extreme
     cases of 0 and 1). We may test this function with X, y and training_ratio values of our own!
    """
    # X_train, y_train, X_test, y_test = None
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=1-training_ratio, train_size=training_ratio, stratify=y)

    return (X_train, y_train, X_test, y_test)


def get_distribution(y):
    count = {}
    y_set = set(map(int, y))
    for y_label in y_set:
        num_count = len(np.where(y == y_label)[0])
        count[y_label] = num_count
    dist_dic = {class_label: num/(1.0*sum(count.values())) for class_label, num in count.items()}
    return dist_dic


def display_distribution(y_train, y_test):
    train_dist = get_distribution(y_train)
    test_dist = get_distribution(y_test)
    print('In train dataset:')
    for k, v in train_dist.items():
        print('Ratio of negative instances = %.2f' % v)
    print('In test dataset:')
    for k, v in test_dist.items():
        print('Ratio of positive instances = %.2f' % v)


def verify_distribution(file_name):
    file_mat = parse_file_into_matrix(file_name)
    X = file_mat[0]
    y = file_mat[1]
    for train_size in [0.8, 0.5, 0.3, 0.1]:
        train_test_set = training_testing_split(X, y, training_ratio=train_size)
        y_train = train_test_set[1]
        y_test = train_test_set[3]
        print('\nWhen training ratio = ', train_size)
        display_distribution(y_train, y_test)


# verify_distribution(file_name='C:/Users/Claire/PycharmProjects/ISE-599/HW3/bank-additional-full.csv')

"""
Q2 (20 points). Run the code above with the X and y that you got from parse_file_into_matrix, with training ratios
of 0.8, 0.5, 0.3 and 0.1. For each of these four cases, what is the 'ratio' of positive instances in the training
dataset to the total number of instances in the training dataset? Verify that this same ratio is achieved in the test
dataset. Write additional code to run these verifications if necessary (5 points per case).
[Output]:
When training ratio =  0.8
In train dataset:
Ratio of negative instances = 0.89
Ratio of negative instances = 0.11
In test dataset:
Ratio of positive instances = 0.89
Ratio of positive instances = 0.11

When training ratio =  0.5
In train dataset:
Ratio of negative instances = 0.89
Ratio of negative instances = 0.11
In test dataset:
Ratio of positive instances = 0.89
Ratio of positive instances = 0.11

When training ratio =  0.3
In train dataset:
Ratio of negative instances = 0.89
Ratio of negative instances = 0.11
In test dataset:
Ratio of positive instances = 0.89
Ratio of positive instances = 0.11

When training ratio =  0.1
In train dataset:
Ratio of negative instances = 0.89
Ratio of negative instances = 0.11
In test dataset:
Ratio of positive instances = 0.89
Ratio of positive instances = 0.11

"""

def train_models(X_train, y_train, model):
    """
    In the code below, I have trained a model specifically for decision tree. You must expand the code to accommodate
    the other two models. To learn more about sklearn's decision trees, see https://scikit-learn.org/stable/modules/tree.html
    :param X_train: self-explanatory
    :param y_train:
    :param model: we will allow three values for model namely 'decision_tree', 'naive_bayes' and 'linear_SGD_classifier'
    (Hint: you must change the loss function in https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.SGDClassifier.html
    to squared_loss to correctly implement the linear classifier. For the naive bayes, the appropriate model to use
    is the Bernoulli naive Bayes.)


    :return:
    """
    if model == 'decision_tree':
        clf = tree.DecisionTreeClassifier()
        clf = clf.fit(X_train, y_train)
        return clf

    if model == 'naive_bayes':
        clf = BernoulliNB(alpha=2.0, fit_prior=True)
        clf.fit(X_train, y_train)
        return clf

    if model == 'linear_SGD_classifier':
        clf = SGDClassifier(loss = 'squared_loss', penalty='l2', alpha=0.001, max_iter=1000, tol=0.001)
        clf.fit(X_train, y_train)
        return clf

    if model == 'random_forest':
        clf = RandomForestClassifier()
        clf.fit(X_train, y_train)
        return clf

    """
    [10 points] Expand/replace 'pass' above to return the other two models based on the value of the model parameter 'model' [10 points]
    [5 points] Expand to return one other model that I have not taught in class.
    """


"""
Code for this function has already been written
"""


def evaluate_model(X_test, y_test, model):
    """
    Note that the model here is different from model in train_models. Here, we will be passing in the 'actual' trained
    model and using it to evaluate X_test and y_test

    We will be using the F_measure metric to evaluate the model: I have already written code in compute_f_measure
     that takes your predicted y, produced in this function, as well as the 'true' y, which is y_test, and will
     return a number to you within 0 and 1. The higher the f-measure, the better. I will briefly explain in class
     why we prefer f-measure over accuracy in many ML tasks.
    """
    y_predict = model.predict(X_test)
    return sklearn.metrics.f1_score(y_test, y_predict)


"""
[20 points] Compile a 5-table report with 10 rows per table. You must submit this report with your assignment submission
(any reasonable format is fine). Each table will correspond to a value of training percent, specifically 10%,30%,50%,70%,90%
Each table will contain four columns (trial number ranging from 1-10, decision_tree, naive_bayes and linear_classifier).
In each cell, you will be reporting the f-measure achieved. Completing this question will also require you to complete
the code for trials() below. trials() does NOT HAVE to (although it could) directly produce the table(s) but must give you all the information
you need, or write information out to file, that is needed for you to populate the tables.

Hint: It is okay to produce and print out intermediate outputs to file if necessary. For example, if you want
you could print out the 'encoded' version of the dataset (which only has numbers) to file, and just read that in
to save on time. Also, if there are some things that are constant, it is perfectly fine to define those constants
or fix variable values outside trials. As always, I want to be reasonable in evaluating these things; the goal is not
to trip you up or make you follow every instruction to the letter.

[15 points] Now we will return to some statistics (you can use whatever tool you want, or even do it manually!). You should
ignore the linear classifier for this question. Our null hypothesis is that the decision tree is better than naive bayes.
(or our alternate hypothesis is that the naive bayes is better than decision tree). For each of the five training percentages,
using 95% as the confidence level, can you reject the null hypothesis? State your p-values here for all five training
percentages. Which test did you use?
ANS: I used one-side paired t-test. It turns out that we should accept the null hypothesis for all of the five training 
percentage.
[Output]:
When training_ratio= 0.1 :
 Statistics= -100.69854632354631 , p_oneside= 2.3826257386683635e-15
 Accept the null hypothesis.
When training_ratio= 0.3 :
 Statistics= -79.82510314369294 , p_oneside= 1.9234362594824638e-14
 Accept the null hypothesis.
When training_ratio= 0.5 :
 Statistics= -59.263010655344246 , p_oneside= 2.794089902542963e-13
 Accept the null hypothesis.
When training_ratio= 0.7 :
 Statistics= -48.82804246602343 , p_oneside= 1.5889959001752628e-12
 Accept the null hypothesis.
When training_ratio= 0.9 :
 Statistics= -26.048123075893272 , p_oneside= 4.3695756042800227e-10
 Accept the null hypothesis.

[5 points Extra credit] Using Bonferroni correction, can you determine if the decision tree is the best model overall (for this question,
you have to consider the linear classifier also) for training percentage of 50 assuming a confidence level of 95%?
ANS: It turns out that we should accept both the null hypothesis that decision_tree is better than naive_bayes and that 
decision_tree is better than linear_SGD_classifier, which means thar the decision tree is the best model overall.
[Output]:
The original p-value:
 {('decision_tree', 'naive_bayes'): 1.4698246509145601e-13, ('decision_tree', 'linear_SGD_classifier'): 3.236702372591154e-08}
P-value after adjustion:
[ True  True]
[2.93964930e-13 6.47340475e-08]
"""


def trials(X, y, training_ratio):
    """
    Think of this as the 'main' or master function from which you will be calling all other code. You must modify
    this code appropriately for your experiments (e.g., to vary training percentage, write out results to file etc.)
    I'm not giving you any hints or placeholders for this function; by now, you should be familiar with how to do
    what I've asked here!
    :return:
    """
    model_list = ['decision_tree', 'naive_bayes', 'linear_SGD_classifier']
    trial_num_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    f_dic = {}
    f_tree = []
    f_bayes = []
    f_SGD = []
    for trial_num in trial_num_list:
        temp_list = []
        train_test_set = training_testing_split(X, y, training_ratio)
        X_train = train_test_set[0]
        y_train = train_test_set[1]
        X_test = train_test_set[2]
        y_test = train_test_set[3]
        for model in model_list:
            clf = train_models(X_train, y_train, model)
            f1_score = evaluate_model(X_test, y_test, clf)
            temp_list.append(f1_score)
        f_tree.append(temp_list[0])
        f_bayes.append(temp_list[1])
        f_SGD.append(temp_list[2])
    f_dic['trial number ranging from 1-10'] = trial_num_list
    f_dic['decision_tree'] = f_tree
    f_dic['naive_bayes'] = f_bayes
    f_dic['linear_SGD_classifier'] = f_SGD
    return f_dic


def generate_f_frame(X, y, training_ratio):
        f_dic = trials(X, y, training_ratio)
        df_fscore = pd.DataFrame(f_dic)
        return df_fscore


def generate_f_table(input_file, output_file):
    Xy_mat = np.loadtxt(input_file, delimiter=',')
    y = Xy_mat[:, -1]
    X = np.delete(Xy_mat, -1, axis=1)
    X = np.nan_to_num(X)
    y = np.nan_to_num(y)
    writer = pd.ExcelWriter(output_file)
    for training_ratio in [0.1, 0.3, 0.5, 0.7, 0.9]:
        df_fscore = generate_f_frame(X, y, training_ratio)
        print(df_fscore)
        df_fscore.to_excel(output_file, index=False)
        df_fscore.to_excel(excel_writer=writer, sheet_name=str(training_ratio))
    writer.save()
    writer.close()


# generate_f_table(input_file='C:/Users/Claire/PycharmProjects/ISE-599/HW3/Xy_encode_full_update.txt', output_file='C:/Users/Claire/PycharmProjects/ISE-599/HW3/fscore_table_full_update.xls')


def classifier_t_test_(X, y, training_ratio):
    df_fscore = generate_f_frame(X, y, training_ratio)
    stat, p = stats.ttest_rel(df_fscore['naive_bayes'], df_fscore['decision_tree'])
    if stat > 0:
        print('When training_ratio=', training_ratio, ':\n Statistics=', stat, ', p_oneside=', 1-p/2)
    else:
        print('When training_ratio=', training_ratio, ':\n Statistics=', stat, ', p_oneside=', p/2)
    if 1-p/2 >= 0.05:
        print(' Accept the null hypothesis.\n')
    else:
        print(' Reject the null hypothesis.\n')


def master_model_compare(input_file):
    Xy_mat = np.loadtxt(input_file, delimiter=',')
    y = Xy_mat[:, -1]
    X = np.delete(Xy_mat, -1, axis=1)
    X = np.nan_to_num(X)
    y = np.nan_to_num(y)
    for training_ratio in [0.1, 0.3, 0.5, 0.7, 0.9]:
        classifier_t_test_(X, y, training_ratio)


# master_model_compare(input_file='C:/Users/Claire/PycharmProjects/ISE-599/HW3/Xy_encode_full_update.txt')


def multiple_test(X, y, training_ratio):
    pval_list = []
    pval_dict = {}
    df_fscore = generate_f_frame(X, y, training_ratio)
    df_fscore = df_fscore.drop(columns='trial number ranging from 1-10')
    for subset in [('decision_tree', 'naive_bayes'), ('decision_tree', 'linear_SGD_classifier')]:
        stat, p = stats.ttest_rel(df_fscore[subset[1]], df_fscore[subset[0]])
        if stat > 0:
            p_oneside = 1-p/2
        else:
            p_oneside = p/2
        pval_list.append(p_oneside)
        pval_dict[subset] = p_oneside
    print('The original p-value:\n', pval_dict)
    return pval_list


def bonferroni_correction(input_file):
    Xy_mat = np.loadtxt(input_file, delimiter=',')
    y = Xy_mat[:, -1]
    X = np.delete(Xy_mat, -1, axis=1)
    X = np.nan_to_num(X)
    y = np.nan_to_num(y)
    pval_list = multiple_test(X, y, 0.5)
    p_adjusted = multipletests(pval_list, alpha=.05, method='bonferroni')
    print('P-value after adjustion:')
    print(p_adjusted[0])
    print(p_adjusted[1])
    return p_adjusted

# bonferroni_correction(input_file='C:/Users/Claire/PycharmProjects/ISE-599/HW3/Xy_encode_full_update.txt')


