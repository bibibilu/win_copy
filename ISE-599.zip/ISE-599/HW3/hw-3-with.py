import sklearn  # make sure this is installed in your environment.
from sklearn.datasets import *
from sklearn import tree
import pandas as pd
import numpy as np
from collections import Counter
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import BernoulliNB
from sklearn.linear_model import SGDClassifier
from sklearn.ensemble import RandomForestClassifier
from scipy import stats
from statsmodels.sandbox.stats.multicomp import multipletests


col_encode = {}
index_encode = {}


def encode_record_into_vector(record):
    record_dic = {}
    for i in record:
        if type(record[i]) == str:
            if i not in col_encode:
                col_encode[i] = {}
                index_encode[i] = 0
            if record[i] not in col_encode[i]:
                col_encode[i][record[i]] = index_encode[i]
                index = index_encode[i]
                index += 1
                index_encode[i] = index
            record_dic[i] = col_encode[i][record[i]]
        else:
            record_dic[i] = record[i]
    record_df = pd.DataFrame([record_dic])
    x = np.array(record_df.iloc[0])
    return x


def parse_file_into_matrix(file_name):
    X = None
    y = None
    df = pd.read_csv(file_name, sep=';')
    for rowNo in range(0, len(df)):
        row_series = df.iloc[rowNo]
        row_dict = row_series.to_dict()
        row_mat = encode_record_into_vector(row_dict)
        row_X = np.delete(row_mat, -1)
        row_y = row_mat[-1:]
        if X is None:
            X = row_X
            y = row_y
        else:
            tup1 = (X, row_X)
            tup2 = (y, row_y)
            X = np.vstack(tup1)
            y = np.vstack(tup2)
    X = np.nan_to_num(X)
    y = np.nan_to_num(y)
    return (X, y.ravel())


# print(parse_file_into_matrix('C:/Users/Claire/PycharmProjects/ISE-599/HW3/bank-additional-full.csv'))


def generate_encode_file(input_file, output_file):
    file_mat = parse_file_into_matrix(input_file)
    Xy_combine = np.hstack((file_mat[0], file_mat[1]))
    np.savetxt(output_file, Xy_combine, delimiter=',')


# generate_encode_file(input_file='C:/Users/Claire/PycharmProjects/ISE-599/HW3/bank-additional-full.csv', output_file='C:/Users/Claire/PycharmProjects/ISE-599/HW3/Xy_encode_full_update.txt')


def training_testing_split(X, y, training_ratio):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=1 - training_ratio, train_size=training_ratio, stratify=y)
    return (X_train, y_train, X_test, y_test)


def train_models(X_train, y_train, model):
    if model == 'decision_tree':
        clf = tree.DecisionTreeClassifier()
        clf = clf.fit(X_train, y_train)
        return clf
    if model == 'naive_bayes':
        clf = BernoulliNB(alpha=1.0, fit_prior=True)
        clf.fit(X_train, y_train)
        return clf
    if model == 'linear_SGD_classifier':
        clf = SGDClassifier(loss='squared_loss', penalty='l2', alpha=0.01, max_iter=1000, tol=1e-3)
        clf.fit(X_train, y_train)
        return clf


def evaluate_model(X_test, y_test, model):
    y_predict = model.predict(X_test)
    return sklearn.metrics.f1_score(y_test, y_predict)


def trials(X, y, training_ratio):
    model_list = ['decision_tree', 'naive_bayes', 'linear_SGD_classifier']
    trial_num_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    f_dic = {}
    f_tree = []
    f_bayes = []
    f_SGD = []
    for trial_num in trial_num_list:
        temp_list = []
        train_test_set = training_testing_split(X, y, training_ratio)
        X_train = train_test_set[0]
        y_train = train_test_set[1]
        X_test = train_test_set[2]
        y_test = train_test_set[3]
        for model in model_list:
            clf = train_models(X_train, y_train, model)
            f1_score = evaluate_model(X_test, y_test, clf)
            temp_list.append(f1_score)
        f_tree.append(temp_list[0])
        f_bayes.append(temp_list[1])
        f_SGD.append(temp_list[2])
    f_dic['trial number ranging from 1-10'] = trial_num_list
    f_dic['decision_tree'] = f_tree
    f_dic['naive_bayes'] = f_bayes
    f_dic['linear_SGD_classifier'] = f_SGD
    return f_dic


def generate_f_frame(X, y, training_ratio):
    f_dic = trials(X, y, training_ratio)
    df_fscore = pd.DataFrame(f_dic)
    return df_fscore


# def generate_f_table(input_file, output_file):
#     Xy_mat = np.loadtxt(input_file, delimiter=',')
#     y = Xy_mat[:, -1]
#     X = np.delete(Xy_mat, -1, axis=1)
#     X = np.nan_to_num(X)
#     y = np.nan_to_num(y)
#     writer = pd.ExcelWriter(output_file)
#     for training_ratio in [0.1, 0.3, 0.5, 0.7, 0.9]:
#         df_fscore = generate_f_frame(X, y, training_ratio)
#         print(df_fscore)
#         df_fscore.to_excel(output_file, index=False)
#         df_fscore.to_excel(excel_writer=writer, sheet_name=str(training_ratio))
#     writer.save()
#     writer.close()

def generate_f_table(input_file, output_file):
    Xy_mat = parse_file_into_matrix(input_file)
    X = Xy_mat[0]
    y = Xy_mat[1]
    train_size_list = [0.1, 0.3, 0.5, 0.7, 0.9]
    writer = pd.ExcelWriter(output_file)
    for training_ratio in train_size_list:
        df_fscore = generate_f_frame(X, y, training_ratio)
        print(df_fscore)
        df_fscore.to_excel(output_file, index=False)
        df_fscore.to_excel(excel_writer=writer, sheet_name=str(training_ratio))
    writer.save()
    writer.close()


generate_f_table(input_file='C:/Users/Claire/PycharmProjects/ISE-599/HW3/bank-additional-full.csv', output_file='C:/Users/Claire/PycharmProjects/ISE-599/HW3/fscore_table_full_update.xls')
# master(input_file='C:/Users/Claire/PycharmProjects/ISE-599/HW3/bank-additional-full.csv', output_file='C:/Users/Claire/PycharmProjects/ISE-599/HW3/fscore_table_full.xls')

def classifier_t_test_(X, y, training_ratio):
    df_fscore = generate_f_frame(X, y, training_ratio)
    stat, p = stats.ttest_rel(df_fscore['naive_bayes'], df_fscore['decision_tree'])
    if stat > 0:
        print('When training_ratio=', training_ratio, ':\n Statistics=', stat, ', p_oneside=', 1 - p / 2)
    else:
        print('When training_ratio=', training_ratio, ':\n Statistics=', stat, ', p_oneside=', p / 2)
    if 1 - p / 2 >= 0.05:
        print(' Accept the null hypothesis.\n')
    else:
        print(' Reject the null hypothesis.\n')


def master_model_compare(input_file):
    Xy_mat = np.loadtxt(input_file, delimiter=',')
    y = Xy_mat[:, -1]
    X = np.delete(Xy_mat, -1, axis=1)
    X = np.nan_to_num(X)
    y = np.nan_to_num(y)
    for training_ratio in [0.1, 0.3, 0.5, 0.7, 0.9]:
        classifier_t_test_(X, y, training_ratio)


# master_model_compare(input_file='C:/Users/Claire/PycharmProjects/ISE-599/HW3/Xy_encode_full.txt')


def multiple_test(X, y, training_ratio):
    pval_list = []
    pval_dict = {}
    df_fscore = generate_f_frame(X, y, training_ratio)
    df_fscore = df_fscore.drop(columns='trial number ranging from 1-10')
    for subset in [('decision_tree', 'naive_bayes'), ('decision_tree', 'linear_SGD_classifier')]:
        stat, p = stats.ttest_rel(df_fscore[subset[1]], df_fscore[subset[0]])
        if stat > 0:
            p_oneside = 1 - p / 2
        else:
            p_oneside = p / 2
        pval_list.append(p_oneside)
        pval_dict[subset] = p_oneside
    print('The original p-value:\n', pval_dict)
    return pval_list


def bonferroni_correction(input_file):
    Xy_mat = np.loadtxt(input_file, delimiter=',')
    y = Xy_mat[:, -1]
    X = np.delete(Xy_mat, -1, axis=1)
    X = np.nan_to_num(X)
    y = np.nan_to_num(y)
    pval_list = multiple_test(X, y, 0.5)
    p_adjusted = multipletests(pval_list, alpha=.05, method='bonferroni')
    print('P-value after adjustion:')
    print(p_adjusted[0])
    print(p_adjusted[1])
    # return (p_adjusted[0], p_adjusted[1])

# bonferroni_correction(input_file='C:/Users/Claire/PycharmProjects/ISE-599/HW3/Xy_encode_full.txt')

# master(input_file='C:/Users/Claire/PycharmProjects/ISE-599/HW3/bank-additional-full.csv', output_file='C:/Users/Claire/PycharmProjects/ISE-599/HW3/fscore_table_full.xls')